<?php header("content-Type: text/html; charset=utf-8");?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>系统核心错误</title>
</head>

<body>
<h2>错误信息:</h2>
<h3 style="color:#F00"><?php echo $message;?></h3>
</body>
</html>