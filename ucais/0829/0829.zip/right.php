<?php include 'func.php'; ?>
<html>
	<head>
		<title>网站管理</title>
	</head>
	<body>
			<h2>欢迎使用管理后台</h2>
	</body>
</html>