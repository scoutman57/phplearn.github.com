<?php
header("Content-Type:text/html;charset=utf-8");


?>
<html>
	<head>
		<title>网站管理</title>
	</head>
	<body>
			<h2>欢迎使用管理后台</h2>
	</body>
</html>