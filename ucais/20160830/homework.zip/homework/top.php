<?php
header("Content-Type:text/html;charset=utf-8");


?>
<html>
	<head>
		<title>网站管理</title>
	</head>
	<body>
			<h1>网站后台管理</h1>
	</body>
</html>