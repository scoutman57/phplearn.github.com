<?php
/**
  * wechat php test
  */

//define your token
define("TOKEN", "weixin");
//实例化微信对象
$wechatObj = new wechatCallbackapiTest();
//$wechatObj->valid();
//开启自动回复功能
$wechatObj->responseMsg();
//定义类文件
class wechatCallbackapiTest
{
    //实现void方法验证方法:实现对接微信公众平台
	public function valid()
    {
        //接受随机字符串
        $echoStr = $_GET["echostr"];

        //valid signature , option
        //进行用户数组前面验证
        if($this->checkSignature()){
            //如果成功则返回接收到的随机字符串
        	echo $echoStr;
        	exit;
        }
    }

    public function responseMsg()
    {
		//get post data, May be due to the different environments
		$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

      	//extract post data
		if (!empty($postStr)){

              	$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
                //手机端
                $fromUsername = $postObj->FromUserName;
                //微信的公众平台
                $toUsername = $postObj->ToUserName;
                //接受用户发送的关键词
                $keyword = trim($postObj->Content);
                //接受用户消息类型
                $msgType = $postObj->MsgType;
                //时间戳
                $time = time();
                $textTpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>";

                //   回复 text    begin----------------------------------------------
				if ($msgType == 'text')
                {
                    if(!empty( $keyword ))
                    {
                        if ($keyword == '文本')
                        {
                            //设置回复类型为文本类型 'text'
                            $msgType = "text";
                            //设置回复内容
                            $contentStr = "您发送的是文本消息!";
                            //格式化xml模板
                            $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                            //返回xml数据到客户端
                            echo $resultStr;
                        }
                        elseif ($keyword == '吴玉林')
                        {
                            //设置回复类型为文本类型 'text'
                            $msgType = "text";
                            //设置回复内容
                            $contentStr = "逗比吴玉林!";
                            //格式化xml模板
                            $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                            //返回xml数据到客户端
                            echo $resultStr;
                        }
                        elseif ($keyword == '王翔')
                        {
                            //设置回复类型为文本类型 'text'
                            $msgType = "text";
                            //设置回复内容
                            $contentStr = "逗比王翔!";
                            //格式化xml模板
                            $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                            //返回xml数据到客户端
                            echo $resultStr;
                        }
                        elseif ($keyword == '骆同超')
                        {
                            //设置回复类型为文本类型 'text'
                            $msgType = "text";
                            //设置回复内容
                            $contentStr = "逗比骆同超!";
                            //格式化xml模板
                            $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                            //返回xml数据到客户端
                            echo $resultStr;
                        }
                        elseif ($keyword == '最帅的人是谁')
                        {
                            //设置回复类型为文本类型 'text'
                            $msgType = "text";
                            //设置回复内容
                            $contentStr = "当然是我啦!!!";
                            //格式化xml模板
                            $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                            //返回xml数据到客户端
                            echo $resultStr;
                        }
                        else
                        {
                            //设置回复类型为文本类型 'text'
                            $msgType = "text";
                            //设置回复内容
                            $contentStr = "您发送的是文本消息!";
                            //格式化xml模板
                            $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                            //返回xml数据到客户端
                            echo $resultStr;
                        }
                    }
                }
                //   回复   text  end-------------------------------------------------------------------

                elseif ($msgType == 'image')
                {
                    $msgType = "text";
                    $contentStr = "您发送的是图片消息!";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;

                }

                elseif ($msgType == 'voice')
                {
                    $msgType = "text";
                    $contentStr = "您发送的是语音消息!";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;

                }

                elseif ($msgType == 'video')
                {
                    $msgType = "text";
                    $contentStr = "您发送的是视频消息!";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;

                }

                elseif ($msgType == 'shortvideo')
                {
                    $msgType = "text";
                    $contentStr = "您发送的是小视频消息!";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;

                }

                elseif ($msgType == 'location')
                {
                    $msgType = "text";
                    $contentStr = "您发送的是地理位置消息!";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;

                }

                elseif ($msgType == 'link')
                {
                    $msgType = "text";
                    $contentStr = "您发送的是链接消息!";
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;

                }

        }else {
        	echo "";
        	exit;
        }
    }

	private function checkSignature()
	{
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];

		$token = TOKEN;
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );

		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}
}

?>