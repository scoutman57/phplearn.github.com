<?php
   include '/Config/config.php';
   include '/Common/db.php';
   $sql='select * from lunbo';
   $res=db($sql);
   exit(json_encode($res));
