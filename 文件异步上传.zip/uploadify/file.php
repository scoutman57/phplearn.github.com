<?php

$array = array(
	"filename" => "img1.jpg"
);
exit(json_encode($array));


?>